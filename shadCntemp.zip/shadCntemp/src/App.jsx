import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { Button } from './components/ui/button'
import { CarouselDemo } from './components/Demo/CarouselDemo'
import { TabsDemo } from './components/Demo/TabsDemo'
import { SheetDemo } from './components/Demo/SheetDemo'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <Button>Hello</Button>
      <CarouselDemo></CarouselDemo>
      <TabsDemo></TabsDemo>
      <SheetDemo></SheetDemo>
    </>
  )
}

export default App
